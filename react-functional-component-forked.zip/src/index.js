import React from "react";
import { render } from "react-dom";

import Customer from "../Customer";

// Main App component
// renders a list of Messages using data from messages.json
const App = (props) => {
  return (
    <div>
      <Customer />
    </div>
  );
};

render(<App />, document.getElementById("root"));
