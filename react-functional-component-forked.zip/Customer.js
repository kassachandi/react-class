import React, { useEffect, useState } from "react";

function Customer() {
  useEffect(() => {
    console.log("useEfect called");

    fetch("https://mocki.io/v1/d4867d8b-b5d5-4a48-a4ab-79131b5809b8")
      .then((res) => res.json())
      .then((data) => setData(data));
  }, []);

  const [data, setData] = useState([]);

  return (
    <>
      <ul>
        {data.map((item, index) => {
          return <li key={index}>{item.name + " - " + item.city}</li>;
        })}
      </ul>
    </>
  );
}

export default Customer;
